// ============================================================================
// Aura AI Assistant — Side Panel Controller v1.5 (Phase 4 Enhanced)
// Fitur Unggulan:
// 1. 🔄 Bilingual Smart Reply & Live Teleprompter:
//    Bisa otomatis membalas mengikuti BAHASA ASLI halaman/lawan bicara (misal Inggris)
//    lengkap dengan arti dalam bahasa kita (misal Indonesia), ATAU membalas dengan bahasa pilihan!
// 2. 📡 Auto-Sync Live Captions/Chat (MutationObserver untuk Zoom, Meet, YT/FB Live)
// 3. ↪️ 1-Click Insert ke Kotak Komentar/Chat (LinkedIn, Gmail, Zoom, YouTube Live)
// 4. 📋 Generator Notulensi Rapat (Auto MoM - Minutes of Meeting) di Tab Live PRO
// 5. 🌍 Full UI Localization (5 Bahasa) + Pemisahan Tegas Ringkas vs Terjemahan Utuh 1:1
// ============================================================================

const state = {
  mode: "summarize", // 'summarize' | 'translate' | 'reply' | 'live'
  provider: "gemini",
  apiKey: "",
  isPro: false,
  userEmail: "",
  licenseKey: "",
  licensePlan: "", // 'MONTHLY' | 'ANNUAL' | ''
  licenseExpiry: "",
  freeTrialRemaining: 3, // Kuota 3x uji coba gratis fitur Live PRO untuk pengguna baru
  theme: "dark",
  isListening: false,
  isAutoSyncingCC: false,
  recognition: null,
  lastOutputText: "",
  meetingTranscriptHistory: [],
  pageContext: {
    url: "",
    title: "",
    platform: "web",
    platformLabel: "Web Page",
    isLiveStreamOrMeeting: false,
    selectedText: "",
    liveTranscript: "",
    mainText: ""
  }
};

// ============================================================================
// SISTEM KRIPTOGRAFI LICENSE KEY AURA PRO (TERKUNCI BY EMAIL PENGGUNA + TANGGAL)
// Format Key: AURA-[M|Y]-[YYYYMMDD]-[6_CHAR_EMAIL_BOUND_SIGNATURE]
// ============================================================================
const AURA_SECRET_SALT = "AURA_INDIE_SAAS_2026_PRO_SECRET_KEY_V1";

function computeLicenseSignature(planCode, expiryStr, userEmail) {
  const normalizedEmail = (userEmail || "").trim().toLowerCase();
  const raw = `${planCode}:${expiryStr}:${normalizedEmail}:${AURA_SECRET_SALT}`;
  let h1 = 0xdeadbeef ^ raw.length;
  let h2 = 0x41c6ce57 ^ raw.length;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const combined = 4294967296 * (2097151 & h2) + (h1 >>> 0);
  return combined.toString(36).toUpperCase().padStart(6, "0").slice(-6);
}

function verifyAuraLicenseKey(keyString, userEmail) {
  const cleanEmail = (userEmail || "").trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes("@")) {
    return {
      valid: false,
      reason: "Masukkan alamat email akun browser Anda terlebih dahulu."
    };
  }
  if (!keyString || typeof keyString !== "string") {
    return { valid: false, reason: "Kode lisensi belum diisi." };
  }
  const clean = keyString.trim().toUpperCase();
  const match = clean.match(/^AURA-(M|Y)-(\d{8})-([A-Z0-9]{6})$/);
  if (!match) {
    return {
      valid: false,
      reason: "Format lisensi tidak valid (Gunakan format AURA-M-YYYYMMDD-XXXXXX atau AURA-Y-...)"
    };
  }

  const [, planCode, expiryStr, providedSig] = match;
  const expectedSigForEmail = computeLicenseSignature(planCode, expiryStr, cleanEmail);

  if (providedSig !== expectedSigForEmail) {
    return {
      valid: false,
      reason: `Kode lisensi tidak cocok dengan email (${cleanEmail}). Lisensi hanya berlaku untuk email yang didaftarkan!`
    };
  }

  // Cek tanggal kedaluwarsa (YYYYMMDD) terhadap tanggal hari ini
  const year = parseInt(expiryStr.slice(0, 4), 10);
  const month = parseInt(expiryStr.slice(4, 6), 10) - 1;
  const day = parseInt(expiryStr.slice(6, 8), 10);
  const expiryDate = new Date(year, month, day, 23, 59, 59);
  const now = new Date();

  if (now > expiryDate) {
    return {
      valid: false,
      expired: true,
      reason: `Lisensi untuk ${cleanEmail} telah kedaluwarsa pada ${expiryDate.toLocaleDateString()}.`
    };
  }

  return {
    valid: true,
    email: cleanEmail,
    plan: planCode === "Y" ? "ANNUAL (Tahunan)" : "MONTHLY (Bulanan)",
    planShort: planCode === "Y" ? "PRO YEARLY" : "PRO MONTHLY",
    expiryFormatted: `${expiryStr.slice(0, 4)}-${expiryStr.slice(4, 6)}-${expiryStr.slice(6, 8)}`
  };
}

// ============================================================================
// KAMUS MULTI-BAHASA ANTARMUKA EKSTENSI (FULL UI LOCALIZATION)
// ============================================================================
const UI_I18N = {
  "Bahasa Indonesia": {
    code: "id",
    voice: "id-ID",
    label: "Bahasa Indonesia",
    apiConnected: (p) => `🔒 Mode AI Penuh: ${p} Aktif`,
    apiFreeMode: "⚡ Mode Instan Gratis Aktif (Klik ⚙️ untuk API Key AI Penuh)",
    settingsTitle: "🔒 Keamanan AI & Status Langganan",
    settingsDesc: "API Key disimpan aman di perangkat Anda (chrome.storage.local).",
    providerLabel: "Penyedia Model AI",
    apiKeyLabel: "Kunci API (API Key)",
    apiKeyPlaceholder: "Tempel API Key Anda di sini...",
    proToggleTitle: "👑 Status Paket Aura Pro",
    proToggleDesc: "Aktifkan untuk menguji fitur berbayar (Zoom, Meet, FB/YT Live Stream Dialog).",
    saveBtn: "💾 Simpan Pengaturan",
    clearBtn: "Hapus Key",
    tabSummarize: "📄 Ringkas",
    tabTranslate: "🌐 Terjemah",
    tabReply: "💬 Reply",
    tabLive: "🔴 Live",
    paywallTitle: "Fitur Eksklusif Aura PRO",
    paywallDesc:
      "Mode Live Meeting & Stream Dialog Copilot (Zoom Web, Google Meet, YouTube Live, Facebook Live, TikTok Live) adalah fitur berbayar.",
    paywallFreeItem:
      "✅ Gratis di Akun Anda: Ringkas, Terjemahkan Utuh & Suara (Mic/Baca) di halaman web, GitHub & LinkedIn.",
    paywallProItem:
      "🔒 Fitur Aura PRO: Auto-Sync Caption, Teleprompter Real-Time & Notulensi Rapat (MoM) untuk Zoom & Live Stream.",
    unlockProBtn: "✨ Coba Aura PRO Sekarang (Mode Demo)",
    langLabel: "Bahasa Ekstensi & Arti",
    styleLabelSummarize: "Gaya Ringkasan",
    styleLabelTranslate: "Mode Terjemahan",
    styleLabelReply: "Bahasa Jawaban / Reply",
    optBullets: "📌 Poin Penting",
    optShort: "⚡ Singkat (TL;DR)",
    optAcademic: "🎓 Akademis / Riset",
    optPro: "💼 Profesional / Rapat",
    optFullTranslate: "📖 Terjemahan Utuh (Paragraf 1:1)",
    // Opsi khusus saat berada di mode Reply atau Live PRO:
    optReplyAutoNative: "🔄 Bahasa Asli Halaman + Arti",
    optReplyUserLang: "🎯 Gunakan Bahasa Pilihan Saya",
    optReplyBilingualEn: "🇬🇧 Jawab English + Arti Indo",
    optReplyFormal: "💼 Formal & Eksekutif",
    promptLabel: "Instruksi / Transkrip Suara & Live",
    autoSyncBtnOff: "📡 Auto-Sync CC",
    autoSyncBtnOn: "🔴 Sync Aktif",
    momBtn: "📋 Notulensi (MoM)",
    promptPlaceholderWeb: "Blok teks di web, bicara via Mic (Gratis), atau langsung klik tombol aksi...",
    promptPlaceholderSelected: (n) => `✅ Teks yang Anda blok terdeteksi (${n} karakter). Siap diproses!`,
    promptPlaceholderLive: (p) => `🎥 Terdeteksi ${p}! Gunakan tab 🔴 Live PRO untuk dialog real-time.`,
    btnSummarize: "✨ Buat Ringkasan Inti",
    btnTranslate: "🌐 Terjemahkan Utuh (Tanpa Diringkas)",
    btnReply: "💬 Buat Opsi Balasan",
    btnLive: "🔴 Analisis & Teleprompter Live",
    btnMic: "Bicara (Mic)",
    btnLiveMic: "Live Listen",
    btnListening: "Mendengarkan...",
    outputTitle: "Hasil Analisis Aura",
    btnInsertChat: "↪️ Insert ke Chat",
    btnInserted: "✅ Masuk ke Chat!",
    btnRead: "🔊 Baca",
    btnStop: "⏹️ Stop",
    btnCopy: "📋 Salin",
    btnCopied: "✅ Tersalin!",
    pillAgree: "✅ Setuju & Lanjut",
    pillReview: "⏳ Minta Waktu Review",
    pillAsk: "❓ Tanya Detail",
    emptyText:
      "Klik tombol aksi di atas, blok teks di halaman web, atau tekan 🎙️ Bicara (Mic) untuk mulai berinteraksi.",
    refreshLink: "🔄 Segarkan Konteks",
    processingMsg: (l) => `⏳ Aura sedang memproses (${l})...`,
    chipInsertLabel: "↪️ Masukkan Kalimat Ini ke Kolom Komentar/Chat"
  },
  English: {
    code: "en",
    voice: "en-US",
    label: "English",
    apiConnected: (p) => `🔒 Full AI Mode: ${p} Active`,
    apiFreeMode: "⚡ Free Instant Mode Active (Click ⚙️ to add AI API Key)",
    settingsTitle: "🔒 AI Security & Subscription Status",
    settingsDesc: "Your API Key is stored locally on your device (chrome.storage.local).",
    providerLabel: "AI Model Provider",
    apiKeyLabel: "API Key",
    apiKeyPlaceholder: "Paste your API Key here...",
    proToggleTitle: "👑 Aura Pro Subscription Status",
    proToggleDesc: "Enable to test paid features (Zoom, Meet, FB/YT Live Stream Dialog).",
    saveBtn: "💾 Save Settings",
    clearBtn: "Clear Key",
    tabSummarize: "📄 Summary",
    tabTranslate: "🌐 Translate",
    tabReply: "💬 Reply",
    tabLive: "🔴 Live",
    paywallTitle: "Aura PRO Exclusive Feature",
    paywallDesc:
      "Live Meeting & Stream Dialog Copilot (Zoom Web, Google Meet, YouTube Live, Facebook Live, TikTok Live) requires Aura PRO.",
    paywallFreeItem:
      "✅ Free in Your Plan: Summarize, Full Translate & Voice (Mic/TTS) on web pages, GitHub & LinkedIn.",
    paywallProItem:
      "🔒 Aura PRO Feature: Auto-Sync Captions, Real-Time Teleprompter & Auto Meeting Notes (MoM).",
    unlockProBtn: "✨ Try Aura PRO Now (Demo Mode)",
    langLabel: "App & Meaning Language",
    styleLabelSummarize: "Summary Style",
    styleLabelTranslate: "Translation Mode",
    styleLabelReply: "Reply Language Mode",
    optBullets: "📌 Key Bullet Points",
    optShort: "⚡ Short (TL;DR)",
    optAcademic: "🎓 Academic / Research",
    optPro: "💼 Professional / Meeting",
    optFullTranslate: "📖 Full 1:1 Translation (No Summary)",
    optReplyAutoNative: "🔄 Match Page Language + Meaning",
    optReplyUserLang: "🎯 Reply in My Selected Language",
    optReplyBilingualEn: "🇬🇧 Reply in English + Meaning",
    optReplyFormal: "💼 Executive & Formal",
    promptLabel: "Instruction / Voice & Live Transcript",
    autoSyncBtnOff: "📡 Auto-Sync CC",
    autoSyncBtnOn: "🔴 Sync Active",
    momBtn: "📋 Meeting Notes (MoM)",
    promptPlaceholderWeb: "Highlight text on page, speak via Mic (Free), or click the action button...",
    promptPlaceholderSelected: (n) => `✅ Highlighted text detected (${n} chars). Ready to process!`,
    promptPlaceholderLive: (p) => `🎥 Detected ${p}! Switch to 🔴 Live PRO tab for real-time dialog.`,
    btnSummarize: "✨ Summarize Key Points",
    btnTranslate: "🌐 Translate Full Text (1:1)",
    btnReply: "💬 Generate Smart Replies",
    btnLive: "🔴 Live Analysis & Teleprompter",
    btnMic: "Speak (Mic)",
    btnLiveMic: "Live Listen",
    btnListening: "Listening...",
    outputTitle: "Aura Output",
    btnInsertChat: "↪️ Insert to Chat",
    btnInserted: "✅ Inserted!",
    btnRead: "🔊 Listen",
    btnStop: "⏹️ Stop",
    btnCopy: "📋 Copy",
    btnCopied: "✅ Copied!",
    pillAgree: "✅ Agree & Proceed",
    pillReview: "⏳ Need Time to Review",
    pillAsk: "❓ Ask Follow-up",
    emptyText:
      "Click the action button above, highlight text on any page, or press 🎙️ Speak (Mic) to start.",
    refreshLink: "🔄 Refresh Context",
    processingMsg: (l) => `⏳ Aura is processing (${l})...`,
    chipInsertLabel: "↪️ Insert This Reply into Comment/Chat Box"
  },
  Japanese: {
    code: "ja",
    voice: "ja-JP",
    label: "日本語",
    apiConnected: (p) => `🔒 フルAIモード: ${p} 有効`,
    apiFreeMode: "⚡ 無料インスタントモード (⚙️をクリックしてAPIキーを設定)",
    settingsTitle: "🔒 AIセキュリティとプラン設定",
    settingsDesc: "APIキーはブラウザ内 (chrome.storage.local) に安全に保存されます。",
    providerLabel: "AIプロバイダー",
    apiKeyLabel: "APIキー",
    apiKeyPlaceholder: "ここにAPIキーを貼り付け...",
    proToggleTitle: "👑 Aura Pro ステータス",
    proToggleDesc: "Zoom、Meet、YouTube/FBライブ対話機能（有料版）をテストします。",
    saveBtn: "💾 設定を保存",
    clearBtn: "削除",
    tabSummarize: "📄 要約",
    tabTranslate: "🌐 翻訳",
    tabReply: "💬 返信",
    tabLive: "🔴 ライブ",
    paywallTitle: "Aura PRO 限定機能",
    paywallDesc: "Zoom、Google Meet、YouTube/FBライブストリーム対話アシスタントはPRO限定機能です。",
    paywallFreeItem: "✅ 無料機能: ウェブページ、GitHub、LinkedInの要約・全文翻訳・音声入力/読み上げ。",
    paywallProItem: "🔒 PRO機能: 字幕自動同期・バイリンガルプロンプター・議事録作成 (MoM)。",
    unlockProBtn: "✨ Aura PRO を試す (デモ)",
    langLabel: "表示＆解説言語",
    styleLabelSummarize: "要約スタイル",
    styleLabelTranslate: "翻訳モード",
    styleLabelReply: "返信の言語モード",
    optBullets: "📌 重要ポイント",
    optShort: "⚡ 短縮 (TL;DR)",
    optAcademic: "🎓 学術・リサーチ",
    optPro: "💼 ビジネス・会議",
    optFullTranslate: "📖 全文そのまま翻訳 (要約なし)",
    optReplyAutoNative: "🔄 相手の言語に合わせる＋日本語訳",
    optReplyUserLang: "🎯 選択した言語で返信",
    optReplyBilingualEn: "🇬🇧 英語で返信＋日本語訳",
    optReplyFormal: "💼 フォーマル・ビジネス",
    promptLabel: "追加指示 / 音声＆ライブ字幕",
    autoSyncBtnOff: "📡 字幕同期",
    autoSyncBtnOn: "🔴 同期中",
    momBtn: "📋 議事録 (MoM)",
    promptPlaceholderWeb: "テキストを選択するか、マイクで話すか、下のボタンを押してください...",
    promptPlaceholderSelected: (n) => `✅ 選択テキストを検出 (${n}文字)。準備完了！`,
    promptPlaceholderLive: (p) => `🎥 ${p}を検出！🔴ライブPROタブでリアルタイム対話が可能です。`,
    btnSummarize: "✨ ページを要約する",
    btnTranslate: "🌐 全文を翻訳する (要約なし)",
    btnReply: "💬 返信案を作成",
    btnLive: "🔴 ライブ分析＆プロンプター",
    btnMic: "音声入力",
    btnLiveMic: "連続リスニング",
    btnListening: "聞き取り中...",
    outputTitle: "Aura 分析結果",
    btnInsertChat: "↪️ チャットに挿入",
    btnInserted: "✅ 挿入完了!",
    btnRead: "🔊 読み上げ",
    btnStop: "⏹️ 停止",
    btnCopy: "📋 コピー",
    btnCopied: "✅ コピー完了",
    pillAgree: "✅ 賛成して進める",
    pillReview: "⏳ 確認の時間を求める",
    pillAsk: "❓ 詳しく質問する",
    emptyText: "上のボタンを押すか、テキストを選択、または 🎙️音声入力 を使って開始してください。",
    refreshLink: "🔄 ページ再検出",
    processingMsg: (l) => `⏳ **${l}** で処理しています...`,
    chipInsertLabel: "↪️ この返信をコメント/チャット欄に挿入"
  },
  Arabic: {
    code: "ar",
    voice: "ar-SA",
    label: "العربية",
    apiConnected: (p) => `🔒 وضع الذكاء الاصطناعي الكامل: ${p}`,
    apiFreeMode: "⚡ الوضع الفوري المجاني (انقر ⚙️ لإضافة مفتاح API)",
    settingsTitle: "🔒 الأمان وحالة الاشتراك",
    settingsDesc: "يتم حفظ مفتاح API محلياً على جهازك فقط.",
    providerLabel: "مزود الذكاء الاصطناعي",
    apiKeyLabel: "مفتاح API",
    apiKeyPlaceholder: "الصق مفتاح API هنا...",
    proToggleTitle: "👑 حالة باقة Aura Pro",
    proToggleDesc: "تفعيل ميزات الاجتماعات والبث المباشر المدفوعة (Zoom, Meet, YT/FB Live).",
    saveBtn: "💾 حفظ الإعدادات",
    clearBtn: "حذف المفتاح",
    tabSummarize: "📄 تلخيص",
    tabTranslate: "🌐 ترجمة",
    tabReply: "💬 رد ذكي",
    tabLive: "🔴 مباشر",
    paywallTitle: "ميزة حصرية لـ Aura PRO",
    paywallDesc: "مساعد الاجتماعات والبث المباشر (Zoom, Meet, YouTube/FB Live) متاح لمشتركي PRO.",
    paywallFreeItem: "✅ مجاناً في حسابك: تلخيص وترجمة كاملة وأوامر صوتية لصفحات الويب وLinkedIn.",
    paywallProItem: "🔒 ميزة PRO: مزامنة الترجمة الفورية وشاشة التلقين وملخص الاجتماع (MoM).",
    unlockProBtn: "✨ جرب Aura PRO الآن (تجريبي)",
    langLabel: "لغة الواجهة والشرح",
    styleLabelSummarize: "أسلوب التلخيص",
    styleLabelTranslate: "وضع الترجمة",
    styleLabelReply: "لغة الرد",
    optBullets: "📌 نقاط رئيسية",
    optShort: "⚡ مختصر (TL;DR)",
    optAcademic: "🎓 أكاديمي / بحثي",
    optPro: "💼 احترافي / اجتماعات",
    optFullTranslate: "📖 ترجمة النص بالكامل (بدون تلخيص)",
    optReplyAutoNative: "🔄 نفس لغة الصفحة + الترجمة",
    optReplyUserLang: "🎯 الردبلغتي المختارة فقط",
    optReplyBilingualEn: "🇬🇧 الرد بالإنجليزية + الترجمة",
    optReplyFormal: "💼 رسمي واحترافي",
    promptLabel: "تعليمات / نص صوتي ومباشر",
    autoSyncBtnOff: "📡 مزامنة النص",
    autoSyncBtnOn: "🔴 متزامن",
    momBtn: "📋 محضر اجتماع",
    promptPlaceholderWeb: "حدد نصاً في الصفحة أو تحدث عبر الميكروفون أو اضغط زر التنفيذ...",
    promptPlaceholderSelected: (n) => `✅ تم تحديد نص (${n} حرف). جاهز للمعالجة!`,
    promptPlaceholderLive: (p) => `🎥 تم اكتشاف ${p}! استخدم تبويب 🔴 PRO للبث المباشر.`,
    btnSummarize: "✨ تلخيص النقاط الهامة",
    btnTranslate: "🌐 ترجمة النص كاملاً (1:1)",
    btnReply: "💬 إنشاء خيارات الرد",
    btnLive: "🔴 تحليل وتلقين مباشر",
    btnMic: "تحدث (مايك)",
    btnLiveMic: "استماع مباشر",
    btnListening: "جارٍ الاستماع...",
    outputTitle: "نتائج Aura",
    btnInsertChat: "↪️ إدراج في الدردشة",
    btnInserted: "✅ تم الإدراج!",
    btnRead: "🔊 قراءة",
    btnStop: "⏹️ إيقاف",
    btnCopy: "📋 نسخ",
    btnCopied: "✅ تم النسخ!",
    pillAgree: "✅ موافق ومتابعة",
    pillReview: "⏳ طلب وقت للمراجعة",
    pillAsk: "❓ سؤال تفصيلي",
    emptyText: "اضغط على الزر أعلاه أو حدد نصاً أو استخدم 🎙️ الميكروفون للبدء.",
    refreshLink: "🔄 تحديث السياق",
    processingMsg: (l) => `⏳ جاري المعالجة (${l})...`,
    chipInsertLabel: "↪️ إدراج هذا الرد في صندوق التعليق/الدردشة"
  },
  "Mandarin Chinese": {
    code: "zh-CN",
    voice: "zh-CN",
    label: "中文",
    apiConnected: (p) => `🔒 完整 AI 模式: ${p} 已启用`,
    apiFreeMode: "⚡ 免费即时模式 (点击 ⚙️ 添加 AI API 密钥)",
    settingsTitle: "🔒 AI 安全与订阅状态",
    settingsDesc: "您的 API 密钥仅保存在本地设备 (chrome.storage.local)。",
    providerLabel: "AI 模型提供商",
    apiKeyLabel: "API 密钥",
    apiKeyPlaceholder: "在此粘贴您的 API Key...",
    proToggleTitle: "👑 Aura Pro 订阅状态",
    proToggleDesc: "开启以测试付费功能 (Zoom、Meet、YouTube/FB 直播对话助手)。",
    saveBtn: "💾 保存设置",
    clearBtn: "清除密钥",
    tabSummarize: "📄 摘要",
    tabTranslate: "🌐 全文翻译",
    tabReply: "💬 智能回复",
    tabLive: "🔴 直播",
    paywallTitle: "Aura PRO 专属功能",
    paywallDesc: "实时会议与直播互动助手 (Zoom, Meet, YouTube/FB/TikTok 直播) 为 PRO 付费功能。",
    paywallFreeItem: "✅ 免费版包含: 网页、GitHub、LinkedIn 摘要、全文翻译及语音输入/朗读。",
    paywallProItem: "🔒 Aura PRO 功能: 自动同步字幕、双语提词器与会议纪要生成 (MoM)。",
    unlockProBtn: "✨ 立即体验 Aura PRO (演示模式)",
    langLabel: "界面与释义语言",
    styleLabelSummarize: "摘要风格",
    styleLabelTranslate: "翻译模式",
    styleLabelReply: "回复语言模式",
    optBullets: "📌 核心要点",
    optShort: "⚡ 极简总结 (TL;DR)",
    optAcademic: "🎓 学术 / 研究",
    optPro: "💼 商务 / 会议",
    optFullTranslate: "📖 1:1 全文完整翻译 (不缩写)",
    optReplyAutoNative: "🔄 匹配原文语言 + 中文释义",
    optReplyUserLang: "🎯 仅使用我选择的语言回复",
    optReplyBilingualEn: "🇬🇧 英文回复 + 中文释义",
    optReplyFormal: "💼 正式商务语气",
    promptLabel: "指令 / 语音与直播字幕",
    autoSyncBtnOff: "📡 自动同步字幕",
    autoSyncBtnOn: "🔴 同步中",
    momBtn: "📋 会议纪要 (MoM)",
    promptPlaceholderWeb: "在网页上划选文字、点击麦克风说话，或直接点击下方按钮...",
    promptPlaceholderSelected: (n) => `✅ 已检测到选中文本 (${n} 字符)，随时可处理！`,
    promptPlaceholderLive: (p) => `🎥 检测到 ${p}！请切换至 🔴 直播 PRO 标签页。`,
    btnSummarize: "✨ 提取核心摘要",
    btnTranslate: "🌐 全文完整翻译 (不缩写)",
    btnReply: "💬 生成智能回复",
    btnLive: "🔴 实时直播分析与提词",
    btnMic: "语音输入",
    btnLiveMic: "连续监听",
    btnListening: "正在倾听...",
    outputTitle: "Aura 分析结果",
    btnInsertChat: "↪️ 插入到聊天框",
    btnInserted: "✅ 已插入!",
    btnRead: "🔊 朗读",
    btnStop: "⏹️ 停止",
    btnCopy: "📋 复制",
    btnCopied: "✅ 已复制!",
    pillAgree: "✅ 同意并推进",
    pillReview: "⏳ 请求时间审阅",
    pillAsk: "❓ 询问细节",
    emptyText: "点击上方操作按钮、划选网页文字或点击 🎙️ 语音输入 开始使用。",
    refreshLink: "🔄 刷新页面上下文",
    processingMsg: (l) => `⏳ Aura 正在以 **${l}** 处理中...`,
    chipInsertLabel: "↪️ 将此回复一键填入评论/聊天框"
  }
};

function t() {
  return UI_I18N[els.langSelect.value] || UI_I18N["English"];
}

const els = {
  planBadge: document.getElementById("planBadge"),
  contextBadge: document.getElementById("contextBadge"),
  themeToggleBtn: document.getElementById("themeToggleBtn"),
  settingsToggleBtn: document.getElementById("settingsToggleBtn"),
  apiStatusBanner: document.getElementById("apiStatusBanner"),
  apiStatusText: document.getElementById("apiStatusText"),
  settingsPanel: document.getElementById("settingsPanel"),
  closeSettingsBtn: document.getElementById("closeSettingsBtn"),
  uiSettingsTitle: document.getElementById("uiSettingsTitle"),
  uiSettingsDesc: document.getElementById("uiSettingsDesc"),
  uiProviderLabel: document.getElementById("uiProviderLabel"),
  providerSelect: document.getElementById("providerSelect"),
  uiApiKeyLabel: document.getElementById("uiApiKeyLabel"),
  apiKeyInput: document.getElementById("apiKeyInput"),
  toggleKeyVisBtn: document.getElementById("toggleKeyVisBtn"),
  uiProToggleTitle: document.getElementById("uiProToggleTitle"),
  uiProToggleDesc: document.getElementById("uiProToggleDesc"),
  licenseStatusPill: document.getElementById("licenseStatusPill"),
  licenseEmailInput: document.getElementById("licenseEmailInput"),
  licenseKeyInput: document.getElementById("licenseKeyInput"),
  licenseMessage: document.getElementById("licenseMessage"),
  saveSettingsBtn: document.getElementById("saveSettingsBtn"),
  clearSettingsBtn: document.getElementById("clearSettingsBtn"),
  tabBtns: document.querySelectorAll(".tab-btn"),
  uiTabSummarize: document.getElementById("uiTabSummarize"),
  uiTabTranslate: document.getElementById("uiTabTranslate"),
  uiTabReply: document.getElementById("uiTabReply"),
  uiTabLive: document.getElementById("uiTabLive"),
  proPaywallCard: document.getElementById("proPaywallCard"),
  uiPaywallTitle: document.getElementById("uiPaywallTitle"),
  uiPaywallDesc: document.getElementById("uiPaywallDesc"),
  paywallEmailInput: document.getElementById("paywallEmailInput"),
  paywallLicenseInput: document.getElementById("paywallLicenseInput"),
  activatePaywallKeyBtn: document.getElementById("activatePaywallKeyBtn"),
  paywallLicenseError: document.getElementById("paywallLicenseError"),
  mainControlsCard: document.getElementById("mainControlsCard"),
  liveTrialBanner: document.getElementById("liveTrialBanner"),
  liveTrialText: document.getElementById("liveTrialText"),
  openLicenseFromTrialBtn: document.getElementById("openLicenseFromTrialBtn"),
  uiLangLabel: document.getElementById("uiLangLabel"),
  langSelect: document.getElementById("langSelect"),
  uiStyleLabel: document.getElementById("uiStyleLabel"),
  styleSelect: document.getElementById("styleSelect"),
  optStyleBullets: document.getElementById("optStyleBullets"),
  optStyleShort: document.getElementById("optStyleShort"),
  optStyleAcademic: document.getElementById("optStyleAcademic"),
  optStylePro: document.getElementById("optStylePro"),
  uiPromptLabel: document.getElementById("uiPromptLabel"),
  liveProToolbar: document.getElementById("liveProToolbar"),
  autoSyncCaptionBtn: document.getElementById("autoSyncCaptionBtn"),
  generateMomBtn: document.getElementById("generateMomBtn"),
  customPromptInput: document.getElementById("customPromptInput"),
  mainActionBtn: document.getElementById("mainActionBtn"),
  voiceInputBtn: document.getElementById("voiceInputBtn"),
  voiceBtnLabel: document.getElementById("voiceBtnLabel"),
  uiOutputTitle: document.getElementById("uiOutputTitle"),
  insertToPageBtn: document.getElementById("insertToPageBtn"),
  ttsPlayBtn: document.getElementById("ttsPlayBtn"),
  ttsStopBtn: document.getElementById("ttsStopBtn"),
  copyResultBtn: document.getElementById("copyResultBtn"),
  exportResultBtn: document.getElementById("exportResultBtn"),
  smartReplyPills: document.getElementById("smartReplyPills"),
  pillAgree: document.getElementById("pillAgree"),
  pillReview: document.getElementById("pillReview"),
  pillAsk: document.getElementById("pillAsk"),
  pillBtns: document.querySelectorAll(".pill-btn"),
  resultContainer: document.getElementById("resultContainer"),
  uiEmptyText: document.getElementById("uiEmptyText"),
  refreshContextLink: document.getElementById("refreshContextLink")
};

// ============================================================================
// 1. INISIALISASI & LOCALIZATION
// ============================================================================

document.addEventListener("DOMContentLoaded", async () => {
  await loadSavedSettings();
  applyUILocalization();
  await detectActiveTabContext();
  await checkPendingContextMenuAction();
  bindEvents();
  bindTabChangeListeners();
});

function bindTabChangeListeners() {
  if (chrome.tabs) {
    chrome.tabs.onActivated.addListener(() => {
      setTimeout(() => detectActiveTabContext(), 250);
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === "complete" && tab.active) {
        detectActiveTabContext();
      }
    });
  }
}

async function loadSavedSettings() {
  // 1. Deteksi otomatis email akun Google yang sedang login di profil browser Chrome pengguna!
  let detectedBrowserEmail = "";
  if (chrome.identity && chrome.identity.getProfileUserInfo) {
    try {
      const userInfo = await new Promise((res) =>
        chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, res)
      );
      if (userInfo && userInfo.email) {
        detectedBrowserEmail = userInfo.email.trim().toLowerCase();
      }
    } catch (e) {
      console.warn("chrome.identity email check:", e);
    }
  }

  return new Promise((resolve) => {
    chrome.storage.local.get(
      [
        "auraProvider",
        "auraApiKey",
        "auraTheme",
        "auraLang",
        "auraUserEmail",
        "auraLicenseKey",
        "auraFreeTrialRemaining"
      ],
      (data) => {
        if (data.auraProvider) {
          state.provider = data.auraProvider;
          els.providerSelect.value = data.auraProvider;
        }
        if (data.auraApiKey) {
          state.apiKey = data.auraApiKey;
          els.apiKeyInput.value = data.auraApiKey;
        }
        if (data.auraTheme) {
          state.theme = data.auraTheme;
          document.documentElement.setAttribute("data-theme", state.theme);
        }
        if (data.auraLang) {
          els.langSelect.value = data.auraLang;
        } else {
          const browserLang = (navigator.language || "en").toLowerCase();
          if (browserLang.startsWith("id")) els.langSelect.value = "Bahasa Indonesia";
          else if (browserLang.startsWith("ja")) els.langSelect.value = "Japanese";
          else if (browserLang.startsWith("ar")) els.langSelect.value = "Arabic";
          else if (browserLang.startsWith("zh")) els.langSelect.value = "Mandarin Chinese";
          else els.langSelect.value = "English";
        }

        if (typeof data.auraFreeTrialRemaining === "number") {
          state.freeTrialRemaining = data.auraFreeTrialRemaining;
        } else {
          state.freeTrialRemaining = 3;
        }

        // Prioritaskan email dari profil login Chrome; jika tidak terdeteksi, gunakan email yang disimpan
        state.userEmail = detectedBrowserEmail || data.auraUserEmail || "";
        if (els.licenseEmailInput) {
          els.licenseEmailInput.value = state.userEmail;
          if (detectedBrowserEmail) {
            els.licenseEmailInput.readOnly = true;
            els.licenseEmailInput.title = "Terkunci otomatis sesuai akun Google yang login di Chrome";
          }
        }
        if (els.paywallEmailInput) {
          els.paywallEmailInput.value = state.userEmail;
          if (detectedBrowserEmail) {
            els.paywallEmailInput.readOnly = true;
          }
        }

        if (data.auraLicenseKey && state.userEmail) {
          state.licenseKey = data.auraLicenseKey;
          els.licenseKeyInput.value = data.auraLicenseKey;
          const check = verifyAuraLicenseKey(data.auraLicenseKey, state.userEmail);
          state.isPro = check.valid;
          state.licensePlan = check.valid ? check.plan : "";
          state.licenseExpiry = check.valid ? check.expiryFormatted : "";
        } else {
          state.isPro = false;
        }

        resolve();
      }
    );
  });
}

function applyUILocalization() {
  const dict = t();

  els.uiSettingsTitle.textContent = dict.settingsTitle;
  els.uiSettingsDesc.textContent = dict.settingsDesc;
  els.uiProviderLabel.textContent = dict.providerLabel;
  els.uiApiKeyLabel.textContent = dict.apiKeyLabel;
  els.apiKeyInput.placeholder = dict.apiKeyPlaceholder;
  els.uiProToggleTitle.textContent = dict.proToggleTitle;
  els.uiProToggleDesc.textContent = dict.proToggleDesc;
  els.saveSettingsBtn.textContent = dict.saveBtn;
  els.clearSettingsBtn.textContent = dict.clearBtn;

  els.uiTabSummarize.textContent = dict.tabSummarize;
  els.uiTabTranslate.textContent = dict.tabTranslate;
  els.uiTabReply.textContent = dict.tabReply;
  els.uiTabLive.textContent = dict.tabLive;

  els.uiPaywallTitle.textContent = dict.paywallTitle;
  els.uiPaywallDesc.textContent = dict.paywallDesc;

  els.uiLangLabel.textContent = dict.langLabel;
  els.uiPromptLabel.textContent = dict.promptLabel;
  els.autoSyncCaptionBtn.textContent = state.isAutoSyncingCC
    ? dict.autoSyncBtnOn
    : dict.autoSyncBtnOff;
  els.generateMomBtn.textContent = dict.momBtn;

  els.uiOutputTitle.textContent = dict.outputTitle;
  els.insertToPageBtn.textContent = dict.btnInsertChat;
  els.ttsPlayBtn.textContent = dict.btnRead;
  els.ttsStopBtn.textContent = dict.btnStop;
  els.copyResultBtn.textContent = dict.btnCopy;

  els.pillAgree.textContent = dict.pillAgree;
  els.pillReview.textContent = dict.pillReview;
  els.pillAsk.textContent = dict.pillAsk;

  if (els.uiEmptyText) {
    els.uiEmptyText.textContent = dict.emptyText;
  }
  els.refreshContextLink.textContent = dict.refreshLink;

  updateStyleOptionsForMode();
  updateApiAndPlanStatusUI();
}

/**
 * Mengatur isi dropdown sebelah kanan sesuai Mode:
 * - Di mode Ringkas: Gaya Ringkasan (Poin Penting / TL;DR / Akademis)
 * - Di mode Terjemah: Mode Terjemahan Utuh 1:1
 * - Di mode Reply & Live PRO: Pilihan Bahasa Jawaban (Bahasa Asli Halaman + Arti vs Bahasa Pilihan Saya!)
 */
function updateStyleOptionsForMode() {
  const dict = t();
  if (state.mode === "translate") {
    els.uiStyleLabel.textContent = dict.styleLabelTranslate;
    els.optStyleBullets.textContent = dict.optFullTranslate;
    els.optStyleShort.textContent = dict.optPro;
    els.optStyleAcademic.textContent = dict.optAcademic;
    els.optStylePro.textContent = dict.optShort;
    els.styleSelect.value = "poin";
  } else if (state.mode === "reply" || state.mode === "live") {
    els.uiStyleLabel.textContent = dict.styleLabelReply;
    els.optStyleBullets.textContent = dict.optReplyAutoNative; // Default: Ikuti Bahasa Asli Halaman + Arti
    els.optStyleShort.textContent = dict.optReplyUserLang; // Gunakan Bahasa Pilihan Saya
    els.optStyleAcademic.textContent = dict.optReplyBilingualEn; // Jawab English + Arti
    els.optStylePro.textContent = dict.optReplyFormal; // Formal & Eksekutif
  } else {
    els.uiStyleLabel.textContent = dict.styleLabelSummarize;
    els.optStyleBullets.textContent = dict.optBullets;
    els.optStyleShort.textContent = dict.optShort;
    els.optStyleAcademic.textContent = dict.optAcademic;
    els.optStylePro.textContent = dict.optPro;
  }

  if (state.mode === "summarize") {
    els.mainActionBtn.textContent = dict.btnSummarize;
    els.voiceBtnLabel.textContent = dict.btnMic;
  } else if (state.mode === "translate") {
    els.mainActionBtn.textContent = dict.btnTranslate;
    els.voiceBtnLabel.textContent = dict.btnMic;
  } else if (state.mode === "reply") {
    els.mainActionBtn.textContent = dict.btnReply;
    els.voiceBtnLabel.textContent = dict.btnMic;
  } else if (state.mode === "live") {
    els.mainActionBtn.textContent = dict.btnLive;
    els.voiceBtnLabel.textContent = dict.btnLiveMic;
  }
}

function updateApiAndPlanStatusUI() {
  const dict = t();
  if (state.isPro) {
    els.planBadge.textContent = `👑 ${state.licensePlan.includes("ANNUAL") ? "PRO YEARLY" : "PRO MONTHLY"}`;
    els.planBadge.className = "plan-badge pro";
    if (els.licenseStatusPill) {
      els.licenseStatusPill.textContent = `Aktif s/d ${state.licenseExpiry}`;
      els.licenseStatusPill.className = "license-pill active";
    }
  } else {
    els.planBadge.textContent = "FREE";
    els.planBadge.className = "plan-badge free";
    if (els.licenseStatusPill) {
      els.licenseStatusPill.textContent = `Free (Trial: ${state.freeTrialRemaining}x)`;
      els.licenseStatusPill.className = "license-pill inactive";
    }
  }

  if (state.apiKey && state.apiKey.trim().length > 8) {
    const providerLabel =
      state.provider === "gemini"
        ? "Google Gemini"
        : state.provider === "openai"
        ? "OpenAI"
        : "Groq";
    els.apiStatusBanner.className = "status-banner success";
    els.apiStatusText.textContent = dict.apiConnected(providerLabel);
  } else {
    els.apiStatusBanner.className = "status-banner warning";
    els.apiStatusText.textContent = dict.apiFreeMode;
  }

  evaluateProGate();
}

function evaluateProGate() {
  const isLiveFeature =
    state.mode === "live" ||
    (state.pageContext.isLiveStreamOrMeeting && state.mode === "reply");

  // Tampilkan info sisa kuota Trial 3x saat user FREE berada di tab Live PRO
  if (els.liveTrialBanner) {
    if (isLiveFeature && !state.isPro && state.freeTrialRemaining > 0) {
      els.liveTrialBanner.classList.remove("hidden");
      els.liveTrialText.innerHTML = `🎁 Free Trial Live PRO tersisa: <strong>${state.freeTrialRemaining}x</strong> klik`;
    } else {
      els.liveTrialBanner.classList.add("hidden");
    }
  }

  // Kunci dengan Paywall apabila user FREE sudah kehabisan kuota 3x Trial!
  if (isLiveFeature && !state.isPro && state.freeTrialRemaining <= 0) {
    els.proPaywallCard.classList.remove("hidden");
    els.mainControlsCard.classList.add("hidden");
  } else {
    els.proPaywallCard.classList.add("hidden");
    els.mainControlsCard.classList.remove("hidden");
  }
}

// ============================================================================
// 2. DETEKSI KONTEKS HALAMAN & PENERIMA AUTO-SYNC LIVE CAPTION
// ============================================================================

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tabs[0] || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
}

async function detectActiveTabContext() {
  const dict = t();
  try {
    const tab = await getActiveTab();
    if (!tab || !tab.id || !tab.url) return null;

    if (
      tab.url.startsWith("chrome://") ||
      tab.url.startsWith("edge://") ||
      tab.url.startsWith("about:") ||
      tab.url.startsWith("chrome-extension://")
    ) {
      els.contextBadge.textContent = "⚙️ Browser Tab";
      return null;
    }

    // Eksekusi ekstraktor LANGSUNG via inline function (Bebas Cache content.js 100%!)
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const url = window.location.href;
        const host = window.location.hostname;
        const title = document.title || "Untitled Page";
        const selectedText = window.getSelection ? window.getSelection().toString().trim() : "";

        let platform = "web";
        let platformLabel = "Web Page";
        let isLiveStreamOrMeeting = false;

        if (host.includes("zoom.us")) {
          platform = "zoom";
          platformLabel = "Zoom Web Meeting";
          isLiveStreamOrMeeting = true;
        } else if (host.includes("meet.google.com")) {
          platform = "meet";
          platformLabel = "Google Meet";
          isLiveStreamOrMeeting = true;
        } else if (host.includes("teams.microsoft.com") || host.includes("teams.live.com")) {
          platform = "teams";
          platformLabel = "Microsoft Teams";
          isLiveStreamOrMeeting = true;
        } else if (host.includes("youtube.com")) {
          const hasLiveChat = !!document.querySelector(
            "ytd-live-chat-frame, #chatframe, .ytp-live-badge"
          );
          platform = "youtube";
          platformLabel = hasLiveChat ? "YouTube Live Stream" : "YouTube Video";
          isLiveStreamOrMeeting = true;
        } else if (host.includes("facebook.com")) {
          const isVideoOrLive =
            url.includes("/videos/") ||
            url.includes("/watch") ||
            url.includes("/live") ||
            !!document.querySelector("video");
          platform = "facebook";
          platformLabel = isVideoOrLive ? "Facebook Live / Video" : "Facebook";
          isLiveStreamOrMeeting = isVideoOrLive;
        } else if (host.includes("tiktok.com")) {
          platform = "tiktok";
          platformLabel = url.includes("/live") ? "TikTok Live Stream" : "TikTok Video";
          isLiveStreamOrMeeting = true;
        } else if (host.includes("twitch.tv")) {
          platform = "twitch";
          platformLabel = "Twitch Live Stream";
          isLiveStreamOrMeeting = true;
        } else if (host.includes("github.com")) {
          platform = "github";
          platformLabel = "GitHub Repository";
        } else if (host.includes("linkedin.com")) {
          platform = "linkedin";
          platformLabel = "LinkedIn";
        } else if (host.includes("mail.google.com")) {
          platform = "gmail";
          platformLabel = "Gmail";
        }

        // Fungsi pembersih noise UI (pelanggan, pengikut, Halaman 1 dari 4, tombol)
        const cleanNoise = (raw) => {
          if (!raw) return "";
          return raw
            .replace(/\d+[\.,]?\d*\s*(pelanggan|pengikut|followers|subscribers)/gi, "")
            .replace(/(halaman|page)\s*\d+\s*(dari|of)\s*\d+/gi, "")
            .split("\n")
            .map((l) => l.trim())
            .filter(
              (l) =>
                l.length > 0 &&
                !/^(\+?\s*ikuti|\+?\s*follow|\+?\s*langganan|\+?\s*subscribe|suka|komentar|bagikan|like|comment|share|pesan|messaging)$/i.test(
                  l
                )
            )
            .join("\n")
            .trim();
        };

        // Ambil hanya dari dalam <main> atau <article> asli halaman agar widget ekstensi lain (seperti AITOPIA) di luar <main> tidak ikut terbaca!
        const scopeRoot =
          document.querySelector("main") ||
          document.querySelector("article") ||
          document.querySelector('[role="main"]') ||
          document.body;

        const paragraphs = [];
        scopeRoot.querySelectorAll("h1, h2, h3, p, blockquote, li").forEach((el) => {
          if (
            el.closest(
              "nav, header, footer, aside, .msg-overlay-list-bubble, .msg-overlay-conversation-bubble, .global-nav, [id*='aitopia' i], [class*='aitopia' i], [id*='extension' i]"
            )
          ) {
            return;
          }
          // Abaikan elemen yang tersembunyi (display: none / visibility: hidden)
          if (el.offsetParent === null) return;

          const txt = cleanNoise(el.innerText || "");
          if (
            txt.length >= 40 &&
            !/aitopia|unggah file pdf|openai images/i.test(txt) &&
            !paragraphs.includes(txt)
          ) {
            paragraphs.push(txt);
          }
        });

        let mainText = paragraphs.join("\n\n");

        // Jika masih sedikit (misal di feed yang pakai <span>/<div>), ambil dari main yang terlihat saja
        if (mainText.length < 300) {
          mainText = cleanNoise(scopeRoot ? scopeRoot.innerText : "");
        }

        mainText = mainText.replace(/\n{3,}/g, "\n\n").substring(0, 15000);

        return {
          url,
          host,
          title,
          platform,
          platformLabel,
          isLiveStreamOrMeeting,
          selectedText,
          liveTranscript: "",
          mainText
        };
      }
    });

    if (results && results[0] && results[0].result) {
      state.pageContext = results[0].result;
      const iconMap = {
        zoom: "📹",
        meet: "📹",
        teams: "📹",
        youtube: "▶️",
        facebook: "📺",
        tiktok: "📱",
        twitch: "🟣",
        github: "🐙",
        linkedin: "💼",
        gmail: "✉️",
        web: "🌐"
      };
      const icon = iconMap[state.pageContext.platform] || "🌐";
      const proTag = state.pageContext.isLiveStreamOrMeeting ? " • LIVE" : "";
      els.contextBadge.textContent = `${icon} ${state.pageContext.platformLabel}${proTag}`;

      if (state.pageContext.liveTranscript) {
        recordMeetingHistory(state.pageContext.liveTranscript);
      }

      if (state.pageContext.isLiveStreamOrMeeting && state.mode === "summarize") {
        els.customPromptInput.placeholder = dict.promptPlaceholderLive(
          state.pageContext.platformLabel
        );
      } else if (state.pageContext.selectedText) {
        els.customPromptInput.placeholder = dict.promptPlaceholderSelected(
          state.pageContext.selectedText.length
        );
      } else {
        els.customPromptInput.placeholder = dict.promptPlaceholderWeb;
      }

      evaluateProGate();
      return state.pageContext;
    }
  } catch (err) {
    console.warn("Context detection error:", err);
  }
  return null;
}

function recordMeetingHistory(newText) {
  if (!newText) return;
  const lastEntry = state.meetingTranscriptHistory[state.meetingTranscriptHistory.length - 1];
  if (lastEntry !== newText) {
    state.meetingTranscriptHistory.push(newText);
    if (state.meetingTranscriptHistory.length > 40) {
      state.meetingTranscriptHistory.shift();
    }
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg) return;
  if (msg.type === "AURA_CONTEXT_ACTION") {
    handleIncomingContextAction(msg);
  } else if (msg.type === "AURA_LIVE_CAPTION_UPDATE" && state.isAutoSyncingCC) {
    els.customPromptInput.value = msg.transcript;
    recordMeetingHistory(msg.transcript);
  }
});

async function checkPendingContextMenuAction() {
  chrome.storage.local.get(["pendingContextAction"], async (res) => {
    if (res && res.pendingContextAction) {
      const act = res.pendingContextAction;
      await chrome.storage.local.remove("pendingContextAction");
      handleIncomingContextAction(act);
    }
  });
}

function handleIncomingContextAction(payload) {
  if (!payload) return;
  switchMode(payload.mode || "summarize");
  if (payload.selectedText) {
    els.customPromptInput.value = payload.selectedText;
  }
  runAuraAction();
}

// ============================================================================
// 3. EVENT LISTENERS & AKSI FASE 4
// ============================================================================

function bindEvents() {
  els.themeToggleBtn.addEventListener("click", () => {
    state.theme = state.theme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", state.theme);
    chrome.storage.local.set({ auraTheme: state.theme });
  });

  // Klik badge FREE/PRO di atas sekarang membuka panel pengaturan Lisensi (Tidak lagi unlock gratis!)
  els.planBadge.addEventListener("click", () => {
    els.settingsPanel.classList.remove("hidden");
    els.licenseKeyInput.focus();
  });

  if (els.openLicenseFromTrialBtn) {
    els.openLicenseFromTrialBtn.addEventListener("click", () => {
      els.settingsPanel.classList.remove("hidden");
      els.licenseKeyInput.focus();
    });
  }

  if (els.activatePaywallKeyBtn) {
    els.activatePaywallKeyBtn.addEventListener("click", () => {
      const candidateEmail = (els.paywallEmailInput?.value || state.userEmail || "").trim();
      const candidateKey = els.paywallLicenseInput.value.trim();
      activateAndSaveLicenseKey(candidateKey, candidateEmail, els.paywallLicenseError);
    });
  }

  els.settingsToggleBtn.addEventListener("click", () => {
    els.settingsPanel.classList.toggle("hidden");
  });
  els.apiStatusBanner.addEventListener("click", () => {
    els.settingsPanel.classList.remove("hidden");
  });
  els.closeSettingsBtn.addEventListener("click", () => {
    els.settingsPanel.classList.add("hidden");
  });

  els.toggleKeyVisBtn.addEventListener("click", () => {
    els.apiKeyInput.type = els.apiKeyInput.type === "password" ? "text" : "password";
  });

  els.saveSettingsBtn.addEventListener("click", () => {
    state.provider = els.providerSelect.value;
    state.apiKey = els.apiKeyInput.value.trim();
    const enteredEmail = (els.licenseEmailInput?.value || state.userEmail || "").trim();
    const enteredLicense = els.licenseKeyInput.value.trim();

    if (enteredLicense) {
      const ok = activateAndSaveLicenseKey(enteredLicense, enteredEmail, els.licenseMessage);
      if (!ok) return; // Jangan tutup panel jika kode lisensi tidak cocok dengan email
    }

    chrome.storage.local.set(
      {
        auraProvider: state.provider,
        auraApiKey: state.apiKey,
        auraUserEmail: enteredEmail.toLowerCase()
      },
      () => {
        updateApiAndPlanStatusUI();
        setTimeout(() => {
          els.settingsPanel.classList.add("hidden");
        }, 500);
      }
    );
  });

  els.clearSettingsBtn.addEventListener("click", () => {
    state.apiKey = "";
    state.licenseKey = "";
    state.isPro = false;
    state.licensePlan = "";
    state.licenseExpiry = "";
    els.apiKeyInput.value = "";
    els.licenseKeyInput.value = "";
    if (els.licenseMessage) els.licenseMessage.textContent = "";
    chrome.storage.local.remove(["auraApiKey", "auraLicenseKey"], () => {
      updateApiAndPlanStatusUI();
    });
  });

  els.langSelect.addEventListener("change", () => {
    chrome.storage.local.set({ auraLang: els.langSelect.value });
    applyUILocalization();
    detectActiveTabContext();
  });

  els.styleSelect.addEventListener("change", () => {
    // Hanya simpan pilihan gaya tanpa memboroskan kuota API sebelum tombol utama diklik
  });

  els.tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      switchMode(btn.dataset.mode);
    });
  });

  els.mainActionBtn.addEventListener("click", () => {
    runAuraAction();
  });

  els.pillBtns.forEach((pill) => {
    pill.addEventListener("click", () => {
      if (state.mode !== "live") switchMode("reply");
      runAuraAction(pill.dataset.intent);
    });
  });

  els.autoSyncCaptionBtn.addEventListener("click", async () => {
    await toggleLiveCaptionObserver();
  });

  els.generateMomBtn.addEventListener("click", async () => {
    await generateMinutesOfMeeting();
  });

  els.insertToPageBtn.addEventListener("click", async () => {
    const cleanReply = extractFirstCleanReply(state.lastOutputText);
    await insertReplyToActiveTab(cleanReply, els.insertToPageBtn);
  });

  els.voiceInputBtn.addEventListener("click", () => {
    toggleSpeechRecognition();
  });

  els.ttsPlayBtn.addEventListener("click", () => {
    speakCurrentResult();
  });
  els.ttsStopBtn.addEventListener("click", () => {
    stopSpeaking();
  });

  els.copyResultBtn.addEventListener("click", async () => {
    if (!state.lastOutputText) return;
    await navigator.clipboard.writeText(state.lastOutputText);
    els.copyResultBtn.textContent = t().btnCopied;
    setTimeout(() => {
      els.copyResultBtn.textContent = t().btnCopy;
    }, 1500);
  });

  els.exportResultBtn.addEventListener("click", () => {
    if (!state.lastOutputText) return;
    const blob = new Blob([state.lastOutputText], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Aura-AI-Notes-${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  });

  els.refreshContextLink.addEventListener("click", async (e) => {
    e.preventDefault();
    const ctx = await detectActiveTabContext();
    if (ctx) {
      renderFormattedResult(
        `**🔄 Context Updated!**\n• **Platform:** ${ctx.platformLabel}\n• **Title:** ${ctx.title}`
      );
    }
  });
}

async function toggleLiveCaptionObserver() {
  const tab = await getActiveTab();
  if (!tab || !tab.id) return;

  state.isAutoSyncingCC = !state.isAutoSyncingCC;
  const dict = t();
  els.autoSyncCaptionBtn.classList.toggle("active", state.isAutoSyncingCC);
  els.autoSyncCaptionBtn.textContent = state.isAutoSyncingCC
    ? dict.autoSyncBtnOn
    : dict.autoSyncBtnOff;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (shouldStart) => {
        if (shouldStart && window.__auraStartLiveObserver) {
          return window.__auraStartLiveObserver();
        } else if (!shouldStart && window.__auraStopLiveObserver) {
          return window.__auraStopLiveObserver();
        }
      },
      args: [state.isAutoSyncingCC]
    });
  } catch (e) {
    console.warn("Observer toggle error:", e);
  }
}

async function generateMinutesOfMeeting() {
  if (!consumeOneFreeTrialIfNeeded()) {
    return;
  }

  await detectActiveTabContext();
  const dict = t();
  const targetLangName = els.langSelect.value;

  const combinedTranscript =
    state.meetingTranscriptHistory.join("\n") ||
    els.customPromptInput.value.trim() ||
    state.pageContext.liveTranscript ||
    state.pageContext.mainText;

  if (!combinedTranscript || combinedTranscript.length < 5) {
    renderFormattedResult("⚠️ Belum ada transkrip rapat/live stream yang tercatat untuk dibuatkan Notulensi (MoM).");
    return;
  }

  renderFormattedResult(dict.processingMsg(dict.label));

  const momPrompt = `You are Aura AI Executive Meeting Secretary (PRO).
Platform: ${state.pageContext.platformLabel} (${state.pageContext.title})
Output Language: ${targetLangName}

Create a professional **Minutes of Meeting (MoM)** document in ${targetLangName} from the following transcript/discussion:
"""
${combinedTranscript.substring(0, 6000)}
"""

Include:
1. **📋 Meeting / Live Stream Overview**
2. **🎯 Key Discussion Points**
3. **✅ Decisions & Action Items (Next Steps)**`;

  try {
    let momResult = "";
    if (state.apiKey && state.apiKey.trim().length > 8) {
      try {
        if (state.provider === "gemini") {
          momResult = await callGeminiAPI(momPrompt);
        } else if (state.provider === "openai") {
          momResult = await callOpenAICompatibleAPI(
            "https://api.openai.com/v1/chat/completions",
            "gpt-4o-mini",
            momPrompt
          );
        } else {
          momResult = await callOpenAICompatibleAPI(
            "https://api.groq.com/openai/v1/chat/completions",
            "llama-3.3-70b-versatile",
            momPrompt
          );
        }
      } catch (apiErr) {
        const topPoints = extractTopSentences(combinedTranscript, 5)
          .map((s) => `• ${s}`)
          .join("\n");
        const translatedPoints = await translateTextFree(topPoints, dict.code);
        momResult = `**📋 Minutes of Meeting (MoM) — ${state.pageContext.platformLabel}**\n**📅 Date:** ${new Date().toLocaleDateString()}\n\n**🎯 Key Discussion & Action Items (${dict.label}):**\n${translatedPoints}`;
      }
    } else {
      const topPoints = extractTopSentences(combinedTranscript, 5)
        .map((s) => `• ${s}`)
        .join("\n");
      const translatedPoints = await translateTextFree(topPoints, dict.code);
      momResult = `**📋 Minutes of Meeting (MoM) — ${state.pageContext.platformLabel}**\n**📅 Date:** ${new Date().toLocaleDateString()}\n\n**🎯 Key Discussion & Action Items (${dict.label}):**\n${translatedPoints}`;
    }

    state.lastOutputText = momResult;
    renderFormattedResult(momResult);
  } catch (err) {
    renderFormattedResult(`❌ **MoM Error:** ${err.message}`);
  }
}

async function insertReplyToActiveTab(textToInsert, btnElement) {
  if (!textToInsert) return;
  try {
    const tab = await getActiveTab();
    if (!tab || !tab.id) return;

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (txt) =>
        window.__auraInsertTextIntoPageInput
          ? window.__auraInsertTextIntoPageInput(txt)
          : { ok: false },
      args: [textToInsert]
    });

    const res = results?.[0]?.result;
    if (res && res.ok) {
      if (btnElement) {
        const prev = btnElement.textContent;
        btnElement.textContent = t().btnInserted;
        setTimeout(() => {
          btnElement.textContent = prev;
        }, 1600);
      }
    } else {
      await navigator.clipboard.writeText(textToInsert);
      alert(
        res?.reason ||
          "Teks telah disalin ke Clipboard! Silakan klik kotak komentar lalu tekan Ctrl+V."
      );
    }
  } catch (err) {
    await navigator.clipboard.writeText(textToInsert);
  }
}

function extractFirstCleanReply(rawText) {
  if (!rawText) return "";
  const quoted = rawText.match(/"([^"]{15,450})"/);
  if (quoted && quoted[1]) return quoted[1].trim();
  return rawText.replace(/\*\*/g, "").trim();
}

function activateAndSaveLicenseKey(rawKey, rawEmail, msgEl) {
  const emailToVerify = (rawEmail || state.userEmail || "").trim().toLowerCase();
  const result = verifyAuraLicenseKey(rawKey, emailToVerify);
  if (!result.valid) {
    state.isPro = false;
    if (msgEl) {
      msgEl.className = "license-msg err";
      msgEl.textContent = `❌ ${result.reason}`;
    }
    updateApiAndPlanStatusUI();
    return false;
  }

  state.userEmail = emailToVerify;
  state.licenseKey = rawKey.trim().toUpperCase();
  state.isPro = true;
  state.licensePlan = result.plan;
  state.licenseExpiry = result.expiryFormatted;
  els.licenseKeyInput.value = state.licenseKey;
  if (els.licenseEmailInput) els.licenseEmailInput.value = state.userEmail;
  if (els.paywallEmailInput) els.paywallEmailInput.value = state.userEmail;

  if (msgEl) {
    msgEl.className = "license-msg ok";
    msgEl.textContent = `✅ Lisensi ${result.plan} Aktif untuk ${state.userEmail} s/d ${result.expiryFormatted}!`;
  }

  chrome.storage.local.set(
    {
      auraUserEmail: state.userEmail,
      auraLicenseKey: state.licenseKey
    },
    () => {
      updateApiAndPlanStatusUI();
    }
  );
  return true;
}

function consumeOneFreeTrialIfNeeded() {
  const isLiveFeature =
    state.mode === "live" ||
    (state.pageContext.isLiveStreamOrMeeting && state.mode === "reply");

  if (!isLiveFeature || state.isPro) return true;

  if (state.freeTrialRemaining <= 0) {
    evaluateProGate();
    return false;
  }

  state.freeTrialRemaining -= 1;
  chrome.storage.local.set({ auraFreeTrialRemaining: state.freeTrialRemaining });
  updateApiAndPlanStatusUI();
  return true;
}

function switchMode(newMode) {
  state.mode = newMode;
  els.tabBtns.forEach((b) => {
    b.classList.toggle("active", b.dataset.mode === newMode);
  });

  els.mainActionBtn.classList.toggle("live-btn", newMode === "live");
  els.smartReplyPills.classList.toggle("hidden", !(newMode === "reply" || newMode === "live"));
  els.liveProToolbar.classList.toggle("hidden", newMode !== "live");
  els.insertToPageBtn.classList.toggle("hidden", !(newMode === "reply" || newMode === "live"));

  updateStyleOptionsForMode();
  evaluateProGate();
}

// ============================================================================
// 4. EKSEKUSI AI (MENDUKUNG JAWABAN BAHASA BAWAAN HALAMAN + ARTI BAHASA KITA)
// ============================================================================

async function runAuraAction(replyIntent = "") {
  if (!consumeOneFreeTrialIfNeeded()) {
    return;
  }

  els.mainActionBtn.disabled = true;
  const dict = t();
  const targetLangName = els.langSelect.value;
  const style = els.styleSelect.value;

  renderFormattedResult(dict.processingMsg(dict.label));

  await detectActiveTabContext();

  const userCustomText = els.customPromptInput.value.trim();
  const sourceContent =
    userCustomText ||
    state.pageContext.selectedText ||
    state.pageContext.liveTranscript ||
    state.pageContext.mainText;

  if (!sourceContent || sourceContent.trim().length < 3) {
    renderFormattedResult("⚠️ No readable text found on this tab.");
    els.mainActionBtn.disabled = false;
    return;
  }

  try {
    let finalOutput = "";

    if (state.apiKey && state.apiKey.trim().length > 8) {
      const prompt = buildPrompt(state.mode, targetLangName, style, sourceContent, replyIntent);
      try {
        if (state.provider === "gemini") {
          finalOutput = await callGeminiAPI(prompt);
        } else if (state.provider === "openai") {
          finalOutput = await callOpenAICompatibleAPI(
            "https://api.openai.com/v1/chat/completions",
            "gpt-4o-mini",
            prompt
          );
        } else if (state.provider === "groq") {
          finalOutput = await callOpenAICompatibleAPI(
            "https://api.groq.com/openai/v1/chat/completions",
            "llama-3.3-70b-versatile",
            prompt
          );
        }
      } catch (apiErr) {
        console.warn("Primary AI API rate-limited or busy, using instant fallback engine:", apiErr);
        // Jika API Key sedang kena Rate Limit per menit (429/404), otomatis gunakan Instant Engine agar tidak pernah gagal!
        finalOutput = await runFreeInstantEngine(
          state.mode,
          dict,
          style,
          sourceContent,
          replyIntent
        );
      }
    } else {
      finalOutput = await runFreeInstantEngine(
        state.mode,
        dict,
        style,
        sourceContent,
        replyIntent
      );
    }

    state.lastOutputText = finalOutput;
    renderFormattedResult(finalOutput);
  } catch (err) {
    renderFormattedResult(`❌ **Error:**\n${err.message || "Check your connection or API Key."}`);
  } finally {
    els.mainActionBtn.disabled = false;
  }
}

function buildPrompt(mode, userLang, replyLangMode, content, replyIntent) {
  const platformInfo = `Platform: ${state.pageContext.platformLabel} (${state.pageContext.title})`;

  // MODE 1: TERJEMAHAN UTUH 1:1 (SELURUH ARTIKEL DARI ATAS SAMPAI BAWAH)
  if (mode === "translate") {
    return `You are a professional translator.
Translate the ENTIRE text below sentence-by-sentence and paragraph-by-paragraph into ${userLang} from beginning to end.
IMPORTANT RULES:
- DO NOT summarize, skip, shorten, or omit any paragraph.
- Translate every single section, heading, and paragraph completely into ${userLang}.
- Output ONLY the direct full translation in ${userLang} without any introductory remarks.

Source Text:
"""
${content.substring(0, 12000)}
"""`;
  }

  // Tentukan aturan bahasa jawaban untuk mode LIVE dan REPLY berdasarkan pilihan dropdown kanan:
  // - 'poin' (Default): Ikuti Bahasa Asli Halaman/Lawan Bicara + Berikan Arti dalam userLang
  // - 'singkat': Gunakan userLang saja
  // - 'akademis': Jawab dalam Bahasa Inggris + Arti dalam userLang
  // - 'profesional': Ikuti Bahasa Asli dengan nada Eksekutif/Formal + Arti dalam userLang
  let replyLanguageInstruction = "";
  if (replyLangMode === "singkat") {
    replyLanguageInstruction = `- Write the spoken/written replies directly in ${userLang} inside double quotes "...".`;
  } else if (replyLangMode === "akademis") {
    replyLanguageInstruction = `- Write each ready-to-send reply in **English** inside double quotes "..." (so it can be 1-click inserted/spoken), and right below it in parentheses (...) provide its meaning/translation in ${userLang}.`;
  } else {
    // Default ('poin' atau 'profesional'): Deteksi bahasa asli teks halaman/lawan bicara!
    replyLanguageInstruction = `- Detect the original language of the Source Context below (e.g., if the post/speaker is in English, reply in English; if Japanese, reply in Japanese).
- Write each ready-to-send reply in that **Original Source Language** wrapped inside double quotes "..." (so the 1-Click Insert button inserts the native language), AND right below it in parentheses (...) provide its translation in **${userLang}** so the user understands the exact meaning!`;
  }

  // MODE 2: LIVE STREAM & ZOOM MEETING COPILOT (PRO)
  if (mode === "live") {
    return `You are Aura AI Live Meeting & Stream Copilot (PRO) for Zoom, Google Meet, YouTube Live, Facebook Live, and TikTok Live.
${platformInfo}
User's Native Language: ${userLang}
${replyIntent ? `Response Direction: ${replyIntent}` : ""}

Source Transcript / Page Content:
"""
${content.substring(0, 4500)}
"""

Provide this structured output:
1. **🎯 Terjemahan & Inti Pembicaraan (${userLang}):** Explain concisely in ${userLang} what the speaker/post is talking about or asking.
2. **🗣️ Teleprompter Jawaban Siap Ucap / Chat:** Give 2 natural responses following this rule:
${replyLanguageInstruction}
3. **📌 Poin Penting (${userLang}):** 2-3 quick bullet points.`;
  }

  // MODE 3: SMART REPLY (BALASAN PESAN / KOMENTAR)
  if (mode === "reply") {
    return `You are Aura AI Assistant for professional communication.
${platformInfo}
User's Meaning Language: ${userLang}
${replyIntent ? `Reply Focus: ${replyIntent}` : ""}

Source Context:
"""
${content.substring(0, 4000)}
"""

Generate 3 ready-to-send replies (1. Professional & Agreeing, 2. Collaborative/Discussion, 3. Insightful Follow-up Question) following this exact language rule:
${replyLanguageInstruction}`;
  }

  // MODE 4: RINGKASAN MENDALAM & KOMPREHENSIF (SUMMARIZE)
  return `You are Aura AI Assistant, an expert research and business analyst.
${platformInfo}
Provide a comprehensive, detailed, and well-structured summary of the entire content below in ${userLang} (Style: ${replyLangMode}).
Structure your response clearly with:
1. **Ringkasan Eksekutif (Executive Summary):** A thorough 1-2 paragraph overview explaining the core context, purpose, and background.
2. **Poin-Poin Utama & Detail Penting (Key Takeaways):** Detailed bullet points with bold sub-labels covering all major sections, technical specs, numbers, and arguments from top to bottom of the article.
3. **Kesimpulan & Implikasi (Conclusion & Actionable Insights):** Key conclusions and practical takeaways.

Source Content:
"""
${content.substring(0, 12000)}
"""`;
}

async function runFreeInstantEngine(mode, dict, replyLangMode, content, replyIntent) {
  if (mode === "translate") {
    const paragraphs = content
      .split(/\n{2,}/)
      .map((p) => p.replace(/\s+/g, " ").trim())
      .filter((p) => p.length > 0);

    // Terjemahkan seluruh artikel per bagian (chunk) agar tidak ada paragraf bawah yang terpotong!
    const chunks = [];
    let currentChunk = "";
    for (const p of paragraphs) {
      if ((currentChunk + "\n\n" + p).length > 1800) {
        if (currentChunk) chunks.push(currentChunk);
        currentChunk = p;
      } else {
        currentChunk = currentChunk ? currentChunk + "\n\n" + p : p;
      }
    }
    if (currentChunk) chunks.push(currentChunk);

    const translatedChunks = [];
    for (const c of chunks.slice(0, 6)) {
      translatedChunks.push(await translateTextFree(c, dict.code));
    }

    const translatedFull = translatedChunks.join("\n\n");
    return `**🌐 Full Translation (${dict.label}) — ${state.pageContext.platformLabel}**\n\n${translatedFull}`;
  }

  const cleanText = content.replace(/\s+/g, " ").trim();

  if (mode === "live") {
    const snippet = cleanText.substring(0, 600);
    const translated = await translateTextFree(snippet, dict.code);
    const enReply =
      "That's a great point! Thank you for sharing that during this session, I completely agree with the direction.";
    const userLangReply = await translateTextFree(enReply, dict.code);

    const primaryQuote = replyLangMode === "singkat" ? userLangReply : enReply;

    return `**🔴 [Aura PRO — Live Stream & Meeting Copilot]**
**📍 Platform:** ${state.pageContext.platformLabel}

**1. 🎯 Terjemahan & Inti (${dict.label}):**
${translated}

**2. 🗣️ Teleprompter Jawaban Siap Ucap / Chat:**
• "${primaryQuote}"
*(Arti ${dict.label}: ${userLangReply})*`;
  }

  if (mode === "reply") {
    const contextSnippet = cleanText.substring(0, 250);
    const translatedContext = await translateTextFree(contextSnippet, dict.code);

    const repliesEN = [
      "Thank you for sharing this insightful update! It is inspiring to see this progress and I look forward to future developments.",
      "Great points! I am also exploring this area and would love to exchange ideas on how this can be applied in practice.",
      "From your perspective, what is the biggest impact or priority we should anticipate next?"
    ];

    const repliesUserLang = await Promise.all(
      repliesEN.map((r) => (dict.code === "en" ? r : translateTextFree(r, dict.code)))
    );

    // Jika mode 'singkat' (Gunakan Bahasa Pilihan Saya), kutipannya memakai bahasa pilihan.
    // Jika mode default ('poin' = Bahasa Asli Halaman + Arti), kutipannya memakai Bahasa Asli (Inggris) + Arti di bawahnya!
    const useUserLangOnly = replyLangMode === "singkat";

    const formattedItems = repliesEN
      .map((enText, i) => {
        const uText = repliesUserLang[i];
        if (useUserLangOnly) {
          return `**Opsi ${i + 1}:**\n"${uText}"`;
        }
        return `**Opsi ${i + 1} (Native + Arti):**\n"${enText}"\n*(Arti: ${uText})*`;
      })
      .join("\n\n");

    return `**💬 Smart Reply (${dict.label})**\n**Konteks:** ${translatedContext.substring(0, 140)}...\n\n${formattedItems}`;
  }

  const keySentences = extractTopSentences(cleanText, replyLangMode === "singkat" ? 5 : 10);
  const bulletSource = keySentences.map((s) => `• ${s}`).join("\n\n");
  const translatedBullets = await translateTextFree(bulletSource, dict.code);

  return `**📌 Comprehensive Summary (${dict.label}) — ${state.pageContext.platformLabel}**\n\n${translatedBullets}`;
}

function extractTopSentences(text, maxCount = 5) {
  const rawSentences = text
    .split(/(?<=[.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 25 && s.length < 320);

  if (rawSentences.length === 0) return [text.substring(0, 300)];

  const freq = {};
  const words = text.toLowerCase().match(/\b[a-zA-Z\u00C0-\u024F]{4,}\b/g) || [];
  words.forEach((w) => {
    freq[w] = (freq[w] || 0) + 1;
  });

  const scored = rawSentences.slice(0, 40).map((sentence, idx) => {
    const sWords = sentence.toLowerCase().match(/\b[a-zA-Z\u00C0-\u024F]{4,}\b/g) || [];
    let score = sWords.reduce((acc, w) => acc + (freq[w] || 0), 0) / (sWords.length + 1);
    if (idx < 3) score *= 1.35;
    return { sentence, score, idx };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored
    .slice(0, maxCount)
    .sort((a, b) => a.idx - b.idx)
    .map((item) => item.sentence);
}

async function translateTextFree(text, targetLangCode) {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(
      targetLangCode
    )}&dt=t&q=${encodeURIComponent(text)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Translation service unavailable");
    const data = await res.json();
    if (Array.isArray(data) && Array.isArray(data[0])) {
      return data[0].map((segment) => segment[0]).join("");
    }
    return text;
  } catch (e) {
    return text;
  }
}

async function callGeminiAPI(prompt) {
  // Prioritaskan gemini-3.0-flash secara langsung karena itu model resmi yang didukung akun baru Google AI Studio Anda!
  const candidateModels = [
    "gemini-3.0-flash",
    "gemini-3.0-flash-001",
    "gemini-2.0-flash"
  ];

  let firstError = null;
  for (const modelName of candidateModels) {
    try {
      const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${encodeURIComponent(
        state.apiKey
      )}`;
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.3 }
        })
      });
      const data = await res.json();
      if (!res.ok) {
        if (!firstError) {
          firstError = new Error(data.error?.message || `HTTP ${res.status}`);
        }
        continue;
      }
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (text) return text;
    } catch (err) {
      if (!firstError) firstError = err;
    }
  }
  throw firstError || new Error("Failed to connect to Google Gemini API.");
}

async function callOpenAICompatibleAPI(url, model, prompt) {
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${state.apiKey}`
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "system",
          content: "You are Aura AI Assistant, a concise multilingual web, voice, and live stream copilot."
        },
        { role: "user", content: prompt }
      ],
      temperature: 0.3
    })
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error?.message || `HTTP ${res.status}`);
  }
  return data.choices?.[0]?.message?.content || "No response from AI.";
}

function renderFormattedResult(markdownText) {
  const escaped = (markdownText || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  let formatted = escaped
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/^\s*[\*\-]\s+(.+)$/gm, "• $1")
    .replace(/\n/g, "<br/>");

  if (state.mode === "reply" || state.mode === "live") {
    const chipLabel = t().chipInsertLabel;
    formatted = formatted.replace(/"([^"\n]{18,450})"/g, (match, replyText) => {
      const safeAttr = replyText.replace(/"/g, "&quot;");
      return `"${replyText}"<br/><button class="reply-insert-chip" data-reply="${safeAttr}">${chipLabel}</button>`;
    });
  }

  els.resultContainer.innerHTML = formatted;

  els.resultContainer.querySelectorAll(".reply-insert-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const replyText = chip.getAttribute("data-reply");
      insertReplyToActiveTab(replyText, chip);
    });
  });
}

// ============================================================================
// 5. FITUR SUARA (SPEECH-TO-TEXT & TEXT-TO-SPEECH MULTI-BAHASA)
// ============================================================================

function toggleSpeechRecognition() {
  if (state.mode === "live" && !state.isPro) {
    evaluateProGate();
    return;
  }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    renderFormattedResult("⚠️ Web Speech API is not supported in this browser.");
    return;
  }

  if (state.isListening && state.recognition) {
    state.recognition.stop();
    return;
  }

  const dict = t();
  const recognition = new SpeechRecognition();
  state.recognition = recognition;

  recognition.lang = dict.voice || "en-US";
  recognition.continuous = state.mode === "live" && state.isPro;
  recognition.interimResults = false;

  recognition.onstart = () => {
    state.isListening = true;
    els.voiceInputBtn.classList.add("listening");
    els.voiceBtnLabel.textContent = dict.btnListening;
    renderFormattedResult(`🎙️ **${dict.btnListening} (${recognition.lang})...**`);
  };

  recognition.onresult = (event) => {
    const lastIdx = event.results.length - 1;
    const transcript = event.results[lastIdx][0].transcript;
    els.customPromptInput.value = transcript;
    recordMeetingHistory(transcript);
    runAuraAction();
  };

  recognition.onerror = (event) => {
    renderFormattedResult(`⚠️ **Mic Error (${event.error}).**`);
  };

  recognition.onend = () => {
    state.isListening = false;
    els.voiceInputBtn.classList.remove("listening");
    els.voiceBtnLabel.textContent = state.mode === "live" ? t().btnLiveMic : t().btnMic;
  };

  recognition.start();
}

function speakCurrentResult() {
  const cleanText = (state.lastOutputText || els.resultContainer.innerText || "").replace(/\*\*/g, "");
  if (!cleanText) return;

  window.speechSynthesis.cancel();

  const dict = t();
  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.lang = dict.voice || "en-US";
  utterance.rate = 1.0;

  utterance.onstart = () => {
    els.ttsPlayBtn.classList.add("hidden");
    els.ttsStopBtn.classList.remove("hidden");
  };

  utterance.onend = () => {
    els.ttsPlayBtn.classList.remove("hidden");
    els.ttsStopBtn.classList.add("hidden");
  };

  utterance.onerror = () => {
    els.ttsPlayBtn.classList.remove("hidden");
    els.ttsStopBtn.classList.add("hidden");
  };

  window.speechSynthesis.speak(utterance);
}

function stopSpeaking() {
  window.speechSynthesis.cancel();
  els.ttsPlayBtn.classList.remove("hidden");
  els.ttsStopBtn.classList.add("hidden");
}
