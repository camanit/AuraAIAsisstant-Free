// ============================================================================
// Aura AI Assistant — Background Service Worker (Manifest V3)
// Mengatur pembukaan Side Panel, Context Menu (Klik Kanan), dan pesan antar tab
// ============================================================================

chrome.runtime.onInstalled.addListener(() => {
  // Buka Side Panel secara otomatis saat ikon ekstensi di toolbar diklik
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel
      .setPanelBehavior({ openPanelOnActionClick: true })
      .catch((err) => console.error("SidePanel behavior error:", err));
  }

  // Buat Context Menu (Klik Kanan pada teks yang diblok di halaman web)
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "aura-summarize-selection",
      title: "✨ Ringkas teks ini dengan Aura AI",
      contexts: ["selection"]
    });

    chrome.contextMenus.create({
      id: "aura-translate-selection",
      title: "🌐 Terjemahkan teks ini dengan Aura AI",
      contexts: ["selection"]
    });

    chrome.contextMenus.create({
      id: "aura-reply-selection",
      title: "💬 Buat opsi balasan (Smart Reply) dengan Aura AI",
      contexts: ["selection"]
    });
  });
});

// Tangani klik pada Context Menu
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !tab.id) return;

  // Buka Side Panel terlebih dahulu di window aktif
  try {
    await chrome.sidePanel.open({ windowId: tab.windowId });
  } catch (e) {
    console.warn("Side panel mungkin sudah terbuka:", e);
  }

  let mode = "summarize";
  if (info.menuItemId === "aura-translate-selection") mode = "translate";
  if (info.menuItemId === "aura-reply-selection") mode = "reply";

  const payload = {
    type: "AURA_CONTEXT_ACTION",
    mode,
    selectedText: info.selectionText || "",
    pageUrl: tab.url || "",
    pageTitle: tab.title || ""
  };

  // Simpan aksi terakhir ke storage agar jika Side Panel baru saja dimuat, ia tetap bisa membacanya
  await chrome.storage.local.set({ pendingContextAction: payload });

  // Kirim pesan langsung apabila Side Panel sudah terbuka
  setTimeout(() => {
    chrome.runtime.sendMessage(payload).catch(() => {
      // Abaikan jika listener belum siap, karena sidepanel.js akan mengecek pendingContextAction
    });
  }, 350);
});

