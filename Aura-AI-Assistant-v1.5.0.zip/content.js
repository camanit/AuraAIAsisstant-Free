// ============================================================================
// Aura AI Assistant — Smart Content Script, Auto Live Observer & 1-Click Inserter (v1.6)
// ============================================================================

(function () {
  if (!window.__auraFocusListenerAttached) {
    window.__auraFocusListenerAttached = true;
    window.__auraLastFocusedEditable = null;

    document.addEventListener(
      "focusin",
      (e) => {
        const el = e.target;
        if (!el) return;
        if (
          el.tagName === "TEXTAREA" ||
          (el.tagName === "INPUT" && ["text", "search", "email"].includes(el.type)) ||
          el.isContentEditable ||
          el.getAttribute?.("role") === "textbox"
        ) {
          window.__auraLastFocusedEditable = el;
        }
      },
      true
    );
  }

  // ============================================================================
  // 1. EKSTRAKTOR KONTEKS HALAMAN & TRANSKRIP LIVE (ANTI JEBAKAN WIDGET KECIL)
  // ============================================================================
  function extractSmartPageContext() {
    const url = window.location.href;
    const host = window.location.hostname;
    const title = document.title || "Untitled Page";
    const selectedText = window.getSelection ? window.getSelection().toString().trim() : "";

    let platform = "web";
    let platformLabel = "Web Page";
    let isLiveStreamOrMeeting = false;

    if (host.includes("zoom.us")) {
      platform = "zoom";
      platformLabel = "Zoom Web Meeting";
      isLiveStreamOrMeeting = true;
    } else if (host.includes("meet.google.com")) {
      platform = "meet";
      platformLabel = "Google Meet";
      isLiveStreamOrMeeting = true;
    } else if (host.includes("teams.microsoft.com") || host.includes("teams.live.com")) {
      platform = "teams";
      platformLabel = "Microsoft Teams";
      isLiveStreamOrMeeting = true;
    } else if (host.includes("youtube.com")) {
      const hasLiveChat = !!document.querySelector(
        "ytd-live-chat-frame, #chatframe, .ytp-live-badge"
      );
      platform = "youtube";
      platformLabel = hasLiveChat ? "YouTube Live Stream" : "YouTube Video";
      isLiveStreamOrMeeting = true;
    } else if (host.includes("facebook.com")) {
      const isVideoOrLive =
        url.includes("/videos/") ||
        url.includes("/watch") ||
        url.includes("/live") ||
        !!document.querySelector("video");
      platform = "facebook";
      platformLabel = isVideoOrLive ? "Facebook Live / Video" : "Facebook";
      isLiveStreamOrMeeting = isVideoOrLive;
    } else if (host.includes("tiktok.com")) {
      platform = "tiktok";
      platformLabel = url.includes("/live") ? "TikTok Live Stream" : "TikTok Video";
      isLiveStreamOrMeeting = true;
    } else if (host.includes("twitch.tv")) {
      platform = "twitch";
      platformLabel = "Twitch Live Stream";
      isLiveStreamOrMeeting = true;
    } else if (host.includes("github.com")) {
      platform = "github";
      platformLabel = "GitHub Repository";
    } else if (host.includes("linkedin.com")) {
      platform = "linkedin";
      platformLabel = "LinkedIn";
    } else if (host.includes("mail.google.com")) {
      platform = "gmail";
      platformLabel = "Gmail";
    }

    const liveTranscript = collectLiveCaptionsAndChat();

    // Kumpulkan seluruh paragraf & heading bermakna dari halaman, tanpa terjebak widget/dialog kecil!
    const allMeaningfulBlocks = [];
    const blockNodes = document.body
      ? document.body.querySelectorAll(
          "h1, h2, h3, p, blockquote, li, article, .update-components-text, .feed-shared-update-v2__description, .markdown-body"
        )
      : [];

    blockNodes.forEach((node) => {
      // Abaikan elemen yang berada di dalam nav, header, footer, aside, atau widget ekstensi lain (seperti AITOPIA)
      if (
        node.closest(
          "nav, header, footer, aside, .msg-overlay-list-bubble, .msg-overlay-conversation-bubble, .global-nav, [id*='aitopia' i], [class*='aitopia' i]"
        ) ||
        node.offsetParent === null
      ) {
        return;
      }

      // Jika node adalah article/container besar yang punya banyak <p> di dalamnya, biarkan <p>-nya yang diambil satu per satu
      if (node.tagName === "ARTICLE" && node.querySelectorAll("p").length > 2) {
        return;
      }

      const cleaned = cleanUITextNoise(node.innerText || "");
      if (cleaned.length > 35) {
        if (
          !allMeaningfulBlocks.some(
            (existing) => existing === cleaned || existing.includes(cleaned)
          )
        ) {
          allMeaningfulBlocks.push(cleaned);
        }
      }
    });

    let mainText = allMeaningfulBlocks.join("\n\n");

    // Jika halaman menggunakan struktur non-standar (misal div semua), fallback ke teks body bersih
    if (mainText.length < 350 && document.body) {
      const mainEl = document.querySelector("main") || document.body;
      mainText = cleanUITextNoise(mainEl.innerText || "");
    }

    mainText = mainText.replace(/\n{3,}/g, "\n\n").substring(0, 8500);

    return {
      url,
      host,
      title,
      platform,
      platformLabel,
      isLiveStreamOrMeeting,
      selectedText,
      liveTranscript,
      mainText
    };
  }

  /**
   * Menghapus teks UI yang mengganggu seperti "31.505 pelanggan", "76.353 pengikut", "Halaman 1 dari 4"
   */
  function cleanUITextNoise(rawText) {
    if (!rawText) return "";
    return rawText
      .replace(/\d+[\.,]?\d*\s+(pelanggan|pengikut|followers|subscribers)/gi, "")
      .replace(/(halaman|page)\s+\d+\s+(dari|of)\s+\d+/gi, "")
      .split("\n")
      .map((line) => line.trim())
      .filter(
        (line) =>
          line.length > 0 &&
          !/^(\+?\s*ikuti|\+?\s*follow|\+?\s*langganan|\+?\s*subscribe|suka|komentar|bagikan|like|comment|share)$/i.test(
            line
          )
      )
      .join("\n")
      .trim();
  }

  function collectLiveCaptionsAndChat() {
    const liveSelectors = [
      '[class*="caption"]',
      '[class*="subtitle"]',
      '[class*="transcript"]',
      '[data-tid*="closed-caption"]',
      ".ytp-caption-segment",
      "yt-live-chat-text-message-renderer #message",
      "#segments-container ytd-transcript-segment-renderer",
      '[data-a-target="chat-line-message-body"]',
      '[data-e2e="chat-message"]',
      '[aria-live="polite"]',
      '[aria-live="assertive"]'
    ];
    const collected = [];
    liveSelectors.forEach((sel) => {
      document.querySelectorAll(sel).forEach((el) => {
        const txt = (el.innerText || "").trim();
        if (txt && txt.length > 3 && !collected.includes(txt)) {
          collected.push(txt);
        }
      });
    });
    return collected.slice(-30).join("\n").slice(-4000);
  }

  // ============================================================================
  // 2. REAL-TIME MUTATION OBSERVER UNTUK LIVE STREAM & ZOOM MEETING
  // ============================================================================
  function startAuraLiveObserver() {
    if (window.__auraLiveObserver) return { status: "already_running" };

    let lastSentTranscript = "";
    window.__auraLiveObserver = new MutationObserver(() => {
      const currentTranscript = collectLiveCaptionsAndChat();
      if (currentTranscript && currentTranscript !== lastSentTranscript) {
        lastSentTranscript = currentTranscript;
        chrome.runtime
          .sendMessage({
            type: "AURA_LIVE_CAPTION_UPDATE",
            transcript: currentTranscript,
            timestamp: new Date().toLocaleTimeString()
          })
          .catch(() => {});
      }
    });

    window.__auraLiveObserver.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });

    return { status: "started" };
  }

  function stopAuraLiveObserver() {
    if (window.__auraLiveObserver) {
      window.__auraLiveObserver.disconnect();
      window.__auraLiveObserver = null;
    }
    return { status: "stopped" };
  }

  // ============================================================================
  // 3. 1-CLICK INSERT KE KOTAK KOMENTAR / CHAT
  // ============================================================================
  function insertTextIntoPageInput(textToInsert) {
    if (!textToInsert) return { ok: false, reason: "Empty text" };

    const candidateSelectors = [
      ".comments-comment-box__form .ql-editor",
      ".comments-comment-texteditor .ql-editor",
      ".msg-form__contenteditable",
      '.ql-editor[contenteditable="true"]',
      'div[aria-label="Message Body"][contenteditable="true"]',
      'div[role="textbox"][g_editable="true"]',
      "#contenteditable-root[contenteditable='true']",
      "yt-live-chat-text-input-field-renderer #input",
      'textarea[placeholder*="message" i]',
      'textarea[placeholder*="pesan" i]',
      'textarea[placeholder*="komentar" i]',
      'textarea[placeholder*="comment" i]',
      '[role="textbox"][contenteditable="true"]',
      '[contenteditable="true"]',
      "textarea"
    ];

    let target = window.__auraLastFocusedEditable;

    if (!target || !document.body.contains(target)) {
      for (const sel of candidateSelectors) {
        const found = document.querySelector(sel);
        if (found && found.offsetParent !== null) {
          target = found;
          break;
        }
      }
    }

    if (!target) {
      return {
        ok: false,
        reason: "Kotak komentar/pesan belum dibuka. Klik dulu kolom komentar di halaman web!"
      };
    }

    target.focus();

    if (target.tagName === "TEXTAREA" || target.tagName === "INPUT") {
      target.value = textToInsert;
      target.dispatchEvent(new Event("input", { bubbles: true }));
      target.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (target.isContentEditable || target.getAttribute("contenteditable") === "true") {
      const success = document.execCommand("insertText", false, textToInsert);
      if (!success) {
        target.innerHTML = `<p>${textToInsert}</p>`;
        target.dispatchEvent(new InputEvent("input", { bubbles: true, data: textToInsert }));
      }
    }

    const prevOutline = target.style.outline;
    target.style.outline = "2px solid #10b981";
    setTimeout(() => {
      target.style.outline = prevOutline;
    }, 1500);

    return { ok: true };
  }

  window.__auraExtractSmartPageContext = extractSmartPageContext;
  window.__auraStartLiveObserver = startAuraLiveObserver;
  window.__auraStopLiveObserver = stopAuraLiveObserver;
  window.__auraInsertTextIntoPageInput = insertTextIntoPageInput;
})();
